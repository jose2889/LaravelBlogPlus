@extends('errors::layout')

@section('title', '403')
@section('message', '¿Pero que estas haciendo? para que intentas ingresas a un zona donde no tienes acceso, por favor comunicate con Jose Hernandez para mas informacion')
