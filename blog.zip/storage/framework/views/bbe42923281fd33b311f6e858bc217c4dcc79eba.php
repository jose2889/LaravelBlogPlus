<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre de la etiqueta')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('slug', 'URL Amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('body', 'Descripcion')); ?>

    <?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/jqueryToSlug/jquery.stringToSlug.min.js')); ?>"></script>

<script>
    $(document).ready(function(){
        // $("#slug").val("La URL se genera automaticamente llenando el campo Nombre");
        $("#slug, #name").stringToSlug({
            callback: function(text){
                $("#slug").val(text);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>