<?php $__env->startSection('title', '403'); ?>
<?php $__env->startSection('message', '¿Pero que estas haciendo? para que intentas ingresas a un zona donde no tienes acceso, por favor comunicate con Jose Hernandez para mas informacion'); ?>

<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>