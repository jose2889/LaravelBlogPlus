<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Ver Categoria
                    <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-sm btn-primary pull-right">Crear</a>
                </div>
                <div class="panel-body">                
                    <p><strong>Nombre</strong>  <?php echo e($category->name); ?></p>
                    <p><strong>Slug</strong>    <?php echo e($category->slug); ?></p>
                    <p><strong>Contenido</strong>    <?php echo e($category->body); ?></p>                    
                                        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>