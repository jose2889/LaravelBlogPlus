<?php echo e(Form::hidden('user_id', auth()->User()->id)); ?>


<div class="form-group">
    <?php echo e(Form::label('category_id', 'Nombre de la Categoria')); ?>

    <?php echo e(Form::select('category_id', $categories, null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre de la etiqueta')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('slug', 'URL Amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('file', 'Imagen')); ?>

    <?php echo e(Form::file('file')); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('status', 'Estado')); ?>

    <label>
    <?php echo e(Form::radio('status', 'PUBLISHED')); ?> Publicado   
    </label>
    <label>
    <?php echo e(Form::radio('status', 'DRAFT')); ?> Borrador   
    </label>
</div>

<div class="form-group">
    <?php echo e(Form::label('tags', 'Etiquetas')); ?>

    <div>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label>
        <!-- pregunta para invetigar: porque se debe cerrar y abrir el helper si todo el codigo es php -->
            <?php echo e(Form::checkbox('tags[]', $tag->id)); ?> <?php echo e($tag->name); ?> 
        
        </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="form-group">
    <?php echo e(Form::label('excerpt', 'Extracto')); ?>

    <?php echo e(Form::textarea('excerpt', null, ['class' => 'form-control', 'rows' => '2'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('body', 'Descripcion')); ?>

    <?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/jqueryToSlug/jquery.stringToSlug.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/editor/ckeditor.js')); ?>"></script>

<script>
    $(document).ready(function(){
        // $("#slug").val("La URL se genera automaticamente llenando el campo Nombre");
        $("#slug, #name").stringToSlug({
            callback: function(text){
                $("#slug").val(text);
            }
        });
    });

    // CKEDITOR.config.height = 400;
    CKEDITOR.config.width = 'auto';
    

    CKEDITOR.replace('body');
</script>
<?php $__env->stopSection(); ?>