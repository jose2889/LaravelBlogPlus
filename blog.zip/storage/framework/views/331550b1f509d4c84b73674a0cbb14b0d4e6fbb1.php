<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-8 col-md-offset-2">
    <h1>Lista de articulos</h1>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="panel panel-default">
            <div class="panel-heading">
                <?php echo e($post->name); ?>

            </div>
            <div class="panel-body">
                <?php if($post->file): ?>
                <img src="<?php echo e($post->file); ?>" class="img-responsive">
                <?php endif; ?>

                <?php echo e($post->excerpt); ?>

                <a href="<?php echo e(route('post', $post->slug)); ?>" class="pull-right">Leer mas</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($posts->render()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>